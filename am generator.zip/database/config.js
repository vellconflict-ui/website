// ©AiiSigma

module.exports = {
  domain: "http://localhost",
  port: "3000"
};

// BOT TOKEN SAMA ID OWNER ADA DI index.js hal 26-27