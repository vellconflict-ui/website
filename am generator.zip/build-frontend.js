const fs = require('fs-extra');
const path = require('path');

const OUT = path.join(__dirname, 'public-build');

async function main() {
  await fs.emptyDir(OUT);

  const folders = ['V5.01', 'toolsPage', 'public'];
  for (const f of folders) {
    const src = path.join(__dirname, f);
    if (fs.existsSync(src)) {
      await fs.copy(src, path.join(OUT, f));
      console.log(`✅ Copied ${f}`);
    }
  }

  // Root Login.html (kalau ada di root)
  const rootLogin = path.join(__dirname, 'Login.html');
  if (fs.existsSync(rootLogin)) {
    await fs.copy(rootLogin, path.join(OUT, 'Login.html'));
    console.log('✅ Copied Login.html (root)');
  }

  // index.html → auto redirect ke /login.html
  await fs.writeFile(
    path.join(OUT, 'index.html'),
    `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0;url=/login.html"></head><body></body></html>`
  );

  // Copy Login.html ke /login.html biar bisa diakses via /login.html
  const loginSrc = path.join(__dirname, 'V5.01', 'Login.html');
  if (fs.existsSync(loginSrc)) {
    await fs.copy(loginSrc, path.join(OUT, 'login.html'));
  }

  // Copy dashboard.html → /dashboard.html
  const dashSrc = path.join(__dirname, 'V5.01', 'dashboard.html');
  if (fs.existsSync(dashSrc)) {
    await fs.copy(dashSrc, path.join(OUT, 'dashboard.html'));
  }

  console.log('🎉 Frontend build selesai → ./public-build');
}

main().catch(err => { console.error(err); process.exit(1); });